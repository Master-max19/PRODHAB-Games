using System;
using System.Collections.Generic;



namespace APIJuegos.Modelos
{
    public class PreguntaJuego
    {
        public int IdPreguntaJuego { get; set; }
        public long IdPregunta { get; set; }
        public int IdJuegos { get; set; }

    }
}