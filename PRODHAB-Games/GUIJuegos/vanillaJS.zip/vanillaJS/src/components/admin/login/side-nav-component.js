(function () {
  class SideNav extends HTMLElement {
    constructor() {
      super();
      this.attachShadow({ mode: "open" });

      this.shadowRoot.innerHTML = `
        <style>
          :host {
            --panel-bg: #ffffff;
            --panel-width: 260px;
            --panel-text: #333;
            --panel-hover: #f2f2f2;
            --btn-bg: #007bff;
            --btn-text: #ffffff;
            --transition-speed: 0.3s;
            font-family: Arial, sans-serif;
          }

          /* Botón de menú */
          #menu-button {
            position: fixed;
            top: 12px;
            left: 12px;
            padding: 10px 16px;
            background-color: var(--btn-bg);
            color: var(--btn-text);
            border: none;
            border-radius: 4px;
            font-size: 16px;
            cursor: pointer;
            z-index: 1001;
            transition: background-color var(--transition-speed);
          }

          #menu-button:hover {
            background-color: #0056b3;
          }

          /* Panel lateral */
          #side-panel {
            position: fixed;
            top: 0;
            left: 0;
            height: 100vh;
            width: var(--panel-width);
            background-color: var(--panel-bg);
            box-shadow: 2px 0 8px rgba(0, 0, 0, 0.2);
            transform: translateX(-100%);
            transition: transform var(--transition-speed) ease;
            z-index: 1000;
            padding: 20px;
          }

          #side-panel.open {
            transform: translateX(0);
          }

          #panel-title {
            font-size: 20px;
            font-weight: bold;
            margin-bottom: 15px;
            color: var(--panel-text);
          }

          .panel-item {
            padding: 10px 12px;
            font-size: 16px;
            color: var(--panel-text);
            border-bottom: 1px solid #ddd;
            cursor: pointer;
            transition: background-color var(--transition-speed);
          }

          .panel-item:hover {
            background-color: var(--panel-hover);
          }
        </style>

        <button id="menu-button">☰ Menú</button>

        <nav id="side-panel" aria-hidden="true">
          <h2 id="panel-title"><slot name="title">Panel</slot></h2>
          <slot></slot>
        </nav>
      `;
    }

    connectedCallback() {
      const button = this.shadowRoot.getElementById("menu-button");
      const panel = this.shadowRoot.getElementById("side-panel");

      button.addEventListener("click", () => {
        const isOpen = panel.classList.toggle("open");
        panel.setAttribute("aria-hidden", !isOpen);
        button.textContent = isOpen ? "✖ Cerrar" : "☰ Menú";
      });

      document.addEventListener("click", (e) => {
        if (
          panel.classList.contains("open") &&
          !panel.contains(e.target) &&
          !button.contains(e.target)
        ) {
          panel.classList.remove("open");
          panel.setAttribute("aria-hidden", "true");
          button.textContent = "☰ Menú";
        }
      });
    }
  }

  window.customElements.define("side-nav", SideNav);
})();
