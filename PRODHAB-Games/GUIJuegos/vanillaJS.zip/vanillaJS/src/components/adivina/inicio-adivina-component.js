class InicioAdivinaComponent extends HTMLElement {
  constructor() {
    super();
    this.attachShadow({ mode: 'open' });
    this.index = 0;

    this.shadowRoot.innerHTML = `
      <style>

    :host {
  /* Variables configurables desde fuera */
  --radius: 16px;
  --card-width: 90%;
  --card-max-width: 600px;
  --card-bg: #fff;
  --card-padding: 18px;
  --btn-bg: #0a0043;
  --btn-bg-hover: #190134;
  --btn-color: #fff;
  --video-width: 60%;
  --video-height: 60%;
  --component-height: auto;  /* 🔹 por defecto se ajusta al contenido */

  display: flex;
  justify-content: center;
  align-items: center;
  width: 100%;
  height: var(--component-height); /* 🔹 modificable */
  text-align: center;
}

.card {
  border-radius: var(--radius);
  box-shadow: 0 10px 30px rgba(20, 30, 60, 0.12);
  padding: var(--card-padding);
  display: flex;
  flex-direction: column;
  gap: 12px;
  align-items: center;
  background-color: var(--card-bg);
  width: var(--card-width);
  max-width: var(--card-max-width);
  margin: auto;
}

.video-wrap {
  width: 100%;
  max-width: var(--card-max-width);
  aspect-ratio: 16/9;
  background-color: var(--card-bg);
  border-radius: var(--radius);
  overflow: hidden;
  display: flex;
  align-items: center;
  justify-content: center;
  position: relative;
}

video {
  width: var(--video-width);
  height: var(--video-height);
  object-fit: cover;
  display: block;
}

.btn {
  margin-top: 16px;
  padding: 10px 24px;
  font-size: 16px;
  font-weight: 600;
  border: none;
  border-radius: 8px;
  background-color: var(--btn-bg);
  color: var(--btn-color);
  cursor: pointer;
  transition: background 0.3s, opacity 0.5s;
  opacity: 0;
  pointer-events: none;
}

.btn.visible {
  opacity: 1;
  pointer-events: auto;
}

.btn:hover {
  background-color: var(--btn-bg-hover);
}

@media (max-width: 520px) {
  .card {
    padding: 12px;
  }
  .btn {
    font-size: 14px;
    width: 80%;
    padding: 8px 20px;
  }
  video {
    width: 80%;
    height: 80%;
  }
}

      </style>

      <main class="card" role="main">
        <h2 style="margin: 0; font-weight: 600; margin-top: 30px;">
          Ordena las palabras
        </h2>
        <p id="streaming-text"></p>

        <div class="video-wrap">
          <video autoplay loop muted playsinline>
            <source src="superando.webm" type="video/webm" />
            Tu navegador no soporta video HTML5.
          </video>
        </div>

        <button id="btn-jugar" class="btn" onclick="nextCard()">
          Jugar
        </button>
      </main>
    `;
  }

  connectedCallback() {
    this.escribir();
  }

  escribir() {
    const texto = "Recuerda leer bien el texto y recordar palabras claves antes de iniciar el juego.";
    const contenedor = this.shadowRoot.getElementById("streaming-text");
    const btnJugar = this.shadowRoot.getElementById("btn-jugar");

    if (this.index < texto.length) {
      contenedor.textContent += texto.charAt(this.index);
      this.index++;
      setTimeout(() => this.escribir(), 50);
    } else {
      btnJugar.classList.add("visible"); // aparece sin expandir
    }
  }
}

customElements.define('inicio-adivina-component', InicioAdivinaComponent);
