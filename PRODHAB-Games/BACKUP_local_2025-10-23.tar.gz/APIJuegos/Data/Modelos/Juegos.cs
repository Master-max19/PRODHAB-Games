﻿using System;
using System.Collections.Generic;


namespace APIJuegos.Data.Modelos
{
    public class Juegos
    {
        public int IdJuegos { get; set; }
        public string Nombre { get; set; } = null!;
    }
}