const cards = document.querySelectorAll(".card");
let current = 0;


updateContainerHeight(); // inicializa altura

function nextCard() {
    if (current < cards.length - 1) {
        cards[current].classList.remove("active");
        current++;
        cards[current].classList.add("active");
    }
}

window.addEventListener("resize", updateContainerHeight);