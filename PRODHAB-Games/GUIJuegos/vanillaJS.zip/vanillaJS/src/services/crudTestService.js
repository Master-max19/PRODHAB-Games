const CRUDTestService = {
  async obtenerPreguntasTestJuego(idJuegos = 1) {
    try {
      const res = await fetch(`${_SERVER}/api/Preguntas/juego/${idJuegos}/con-respuestas`);
      if (!res.ok) throw new Error('Error al obtener preguntas');
      return await res.json();
    } catch (error) {
      console.error('Error fetching questions:', error);
      return [];
    }
  },

  async crearPregunta(pregunta, idJuegos) {
    try {
      const res = await fetch(`${_SERVER}/api/Preguntas/juego/${idJuegos}/con-respuestas`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(pregunta),
      });

      if (!res.ok) throw new Error("Error al crear la pregunta");

      return await res.json();
    } catch (error) {
      console.error("Error creando pregunta:", error);
      return null;
    }
  },

  async actualizarPregunta(pregunta, idPregunta) {
    try {
      const res = await fetch(`${_SERVER}/api/Preguntas/con-respuestas/${idPregunta}`, {
        method: "PUT", // PUT para actualizar
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(pregunta),
      });

      if (!res.ok) throw new Error("Error al actualizar la pregunta");
      return await res.json();
    } catch (error) {
      console.error("Error actualizando pregunta:", error);
      return null;
    }
  },

  async eliminarPregunta(idPregunta) {
    try {
      const res = await fetch(`${_SERVER}/api/Preguntas/${idPregunta}`, {
        method: "DELETE",
        headers: { "Content-Type": "application/json" },
      });

      if (!res.ok) throw new Error("Error al eliminar la pregunta");

      // Si no hay contenido, no intentar parsear JSON
      if (res.status === 204) return { success: true };

      return await res.json();
    } catch (error) {
      console.error("Error eliminando pregunta:", error);
      return null;
    }
  },


  async cambiarEstadoPregunta(idPregunta, activa) {
    try {
      const res = await fetch(`${_SERVER}/api/Preguntas/estado/${idPregunta}/${Boolean(activa)}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
      });

      if (!res.ok) throw new Error("Error al cambiar el estado de la pregunta");

      // Algunos endpoints devuelven 204; otros devuelven el recurso actualizado
      if (res.status === 204) {
        return { success: true, idPregunta, activa: Boolean(activa) };
      }

      return await res.json();
    } catch (error) {
      console.error("Error cambiando estado de la pregunta:", error);
      return null;
    }
  }



};
