namespace APIJuegos.DTOs
{
    public class JuegoConPreguntasDTO
    {
        public int IdJuegos { get; set; }
        public string Nombre { get; set; } = string.Empty;
        public string Descripcion { get; set; } = string.Empty;
        public string Detalle { get; set; } = string.Empty;
        public List<PreguntaConRespuestasDTO> Preguntas { get; set; } = new();
    }

}