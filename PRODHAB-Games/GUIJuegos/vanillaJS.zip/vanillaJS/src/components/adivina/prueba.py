import cv2
import numpy as np
import os

# Abrir video
cap = cv2.VideoCapture(r"C:\Users\50683\Documents\prodhaV1\PRODHAB-Games\PRODHAB-Games\GUIJuegos\vanillaJS\src\components\adivina\superdato_video_saludando.mp4")

# Crear carpeta para frames
os.makedirs("frames", exist_ok=True)

frame_count = 0
while True:
    ret, frame = cap.read()
    if not ret:
        break

    # Convertir a BGRA
    frame = cv2.cvtColor(frame, cv2.COLOR_BGR2BGRA)

    # Quitar fondo blanco
    mask = np.all(frame[:, :, :3] > 240, axis=2)
    frame[mask, 3] = 0  # transparencia

    # Guardar frame como PNG
    cv2.imwrite(f"frames/frame_{frame_count:04d}.png", frame)
    frame_count += 1

cap.release()
