﻿namespace APIJuegos.Data.Modelos
{
    public class sesiones
    {
    }
}
