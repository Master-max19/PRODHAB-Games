class AdminHeaderComponent extends HTMLElement {
  constructor() {
    super();
    this.attachShadow({ mode: "open" });
    this.formTest = null; // inicializar referencia


    this.shadowRoot.innerHTML = `
  <style>
    :host { display: block; font-family:"Raleway", sans-serif; }

    header {
      background: linear-gradient(135deg, #4f46e5, #6366f1);
      padding: 1rem;
      display: flex;
      justify-content: space-between;
      align-items: center;
      color: white;
      flex-wrap: wrap; /* permite que los elementos hagan wrap */
      gap: 1rem;
      font-family:"Raleway", sans-serif;
    }

    .title {
      font-size: 1.5rem;
      font-weight: 600;
    }

    .btn-group {
      display: flex;
      gap: 0.5rem;
      flex-wrap: wrap; /* permite wrap de botones */
    }

    .btn-agregar {
      display: flex;
      align-items: center;
      justify-content: center;
      gap: 0.5rem;
      background: white;
      color: #4f46e5;
      border: 2px solid #4f46e5;
      padding: 0.5rem 1rem;
      font-size: 0.95rem;
      font-weight: 500;
      cursor: pointer;
      border-radius: 6px;
      transition: all 0.2s ease-in-out;
      min-width: 120px;
      flex: 1 1 auto; /* permite que los botones crezcan y se ajusten */
    }

    .btn-agregar:hover {
      background: #eef2ff;
      transform: scale(1.05);
    }

    form-test-component { display: none; }

    /* Media query opcional para pantallas muy pequeñas */
    @media (max-width: 480px) {
      header {
        flex-direction: column;
        align-items: flex-start;
      }
      .btn-group {
        width: 100%;
        gap: 0.5rem;
      }
      .btn-agregar {
        width: 100%; /* botones toman todo el ancho disponible */
      }
    }
  </style>

  <header>
    <div class="title">Test</div>
    <div class="btn-group">
      <button class="btn-agregar"><span>➕</span> Crear pregunta</button>
      <button class="btn-agregar"><span>⚙️</span> Ajustes</button>
    </div>
  </header>
`;


  }

  connectedCallback() {
    this.hideForm();
    const btnAgregar = this.shadowRoot.querySelector(".btn-agregar");
    btnAgregar.addEventListener("click", () => {
      this.showForm(); // siempre mostrar al agregar
    });
  }




  
  showForm() {
    const formTest = document.querySelector("form-test-component");
    if (formTest) {
      formTest.style.display = 'block';
      formTest.setAttribute("modo", "registrar");
      if (typeof formTest.mostrar === "function") {
        formTest.mostrar();
      }
      window.scrollTo({ top: 0, behavior: "smooth" });
    }
  }


  

  // Ocultar el form-test que está afuera
  hideForm() {
    const formTest = document.querySelector("form-test-component");
    if (formTest) formTest.ocultar();
  }
}

customElements.define("admin-header-component", AdminHeaderComponent);
