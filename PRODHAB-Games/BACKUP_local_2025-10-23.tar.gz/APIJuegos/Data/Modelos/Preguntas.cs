﻿using System.Numerics;

namespace APIJuegos.Data.Modelos
{
    public class Preguntas
    {
        public long idPregunta{ get; set; }

        public String enunciado { get; set; }

        public String tipo { get; set; }

        public Boolean activa { get; set; }

    }

}
