const _SERVER = 'http://localhost:5133';
const _PUBLIC = '../../../public/image';

const environments = {
    development: { apiUrl: _SERVER, public: _PUBLIC, debug: true },
    production:  { apiUrl: _SERVER, public: _PUBLIC, debug: false }
};