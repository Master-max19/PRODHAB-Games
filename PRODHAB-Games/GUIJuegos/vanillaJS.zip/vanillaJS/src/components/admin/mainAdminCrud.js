window.addEventListener('DOMContentLoaded', () => {
  const form = document.querySelector('form-test-component');
  const viewer = document.querySelector('test-viewer');
  const modal = document.querySelector('modal-component');

  form.testViewer = viewer;  
  form.modal = modal; // esto asigna correctamente _modal al viewer
  viewer.modal = modal; 
});
